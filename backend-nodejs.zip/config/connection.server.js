var config = {
  port: 5000,
  user: {},
  url: "http://localhost:3000",
};
module.exports = config;
